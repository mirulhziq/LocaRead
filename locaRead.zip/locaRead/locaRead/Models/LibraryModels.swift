import SwiftUI
import CoreGraphics

struct FloorImageSpec: Codable, Equatable {
    let width: CGFloat
    let height: CGFloat
}

struct CGPointCodable: Codable, Equatable {
    let x: CGFloat
    let y: CGFloat
    var point: CGPoint { CGPoint(x: x, y: y) }
}

struct Shelf: Identifiable, Codable, Equatable {
    let id: String          // unique shelf id
    let label: String       // display label for shelf
    let category: String    // e.g. "Computer Science", "Biology"
    let floor: Int
    let x: CGFloat          // coordinate in floor-map space
    let y: CGFloat
}

struct Book: Identifiable, Codable, Equatable, Hashable {
    let id: String          // unique book id
    let title: String
    let callNumber: String
    let category: String
    let shelfId: String     // links to Shelf.id
    let description: String
}

struct LibraryData: Codable, Equatable {
    let image: FloorImageSpec
    let youAreHere: CGPointCodable
    let shelves: [Shelf]
    let books: [Book]
}
