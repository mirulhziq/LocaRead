//
//  BookData.swift
//  NoteNess / locaRead
//
//  Provides in-app sample LibraryData (shelves with coordinates + books)
//  Matches the canonical models in LibraryModels.swift
//

import Foundation
import CoreGraphics

enum BookData {
    static let sample: LibraryData = {
        // Match your floor_map size and you-are-here used elsewhere
        let image = FloorImageSpec(width: 1000, height: 600)

        // Entrance (bottom-left) for Floor 1, matches the photo
        let youAreHere = CGPointCodable(x: 120, y: 520)

        // Shelves:
        // Floor 1: three shelves across the middle row (left/center/right)
        // Floor 2: per your new image:
        //   - Shelf 1: vertical on the left (mid-lower area)
        //   - Shelf 2: horizontal at top-center
        //   - Shelf 3: vertical on the right (mid-lower area)
        // All coordinates are centers placed safely inside each rectangle (1000×600 map).
        let shelves: [Shelf] = [
            // Fiction
            Shelf(id: "FIC-1", label: "A1", category: "Fiction", floor: 1, x: 240, y: 340), // Floor 1, left shelf region
            Shelf(id: "FIC-2", label: "A2", category: "Fiction", floor: 2, x: 150, y: 360), // Floor 2, left vertical

            // History
            Shelf(id: "HIS-1", label: "B1", category: "History", floor: 1, x: 540, y: 340), // Floor 1, center shelf region
            Shelf(id: "HIS-2", label: "B2", category: "History", floor: 2, x: 540, y: 120), // Floor 2, top-center horizontal

            // Science
            Shelf(id: "SCI-1", label: "C1", category: "Science", floor: 1, x: 840, y: 340), // Floor 1, right shelf region
            Shelf(id: "SCI-2", label: "C2", category: "Science", floor: 2, x: 900, y: 360)  // Floor 2, right vertical
        ]

        // Books: id == your asset name (so UIImage(named: id) works)
        let books: [Book] = [
            // Fiction (7)
            Book(
                id: "1984",
                title: "1984",
                callNumber: "PR6029.R8 N49",
                category: "Fiction",
                shelfId: "FIC-1",
                description: "George Orwell’s dystopian masterpiece portrays a future where Big Brother watches everyone, truth is manipulated, and individuality is crushed. Through Winston Smith’s rebellion against the Party, the novel explores surveillance, censorship, and the terrifying cost of losing freedom. It remains a chilling warning about authoritarianism."
            ),
            Book(
                id: "ToKillaMockingBird",
                title: "To Kill a Mockingbird",
                callNumber: "PS3562.E353 T6",
                category: "Fiction",
                shelfId: "FIC-1",
                description: "Harper Lee’s novel is set in the racially divided South during the 1930s. It follows young Scout Finch as her father, lawyer Atticus Finch, defends a Black man wrongly accused of assaulting a white woman. The story examines themes of justice, morality, and the loss of innocence."
            ),
            Book(
                id: "TheGreatGatsby",
                title: "The Great Gatsby",
                callNumber: "PS3511.I9 G7",
                category: "Fiction",
                shelfId: "FIC-1",
                description: "F. Scott Fitzgerald captures the extravagance of the Jazz Age through the eyes of Nick Carraway. The mysterious millionaire Jay Gatsby pursues Daisy Buchanan, the love he lost, but his dream is corrupted by greed, lies, and class divisions. The novel critiques the illusion of the American Dream."
            ),
            Book(
                id: "Pride&Prejudice",
                title: "Pride and Prejudice",
                callNumber: "PR40434.P7",
                category: "Fiction",
                shelfId: "FIC-2",
                description: "ane Austen’s witty romance follows Elizabeth Bennet as she navigates family pressures, social expectations, and her evolving feelings for the proud Mr. Darcy. Through sharp dialogue and satirical humor, the novel critiques class, gender roles, and the misunderstandings that shape human relationships."
            ),
            Book(
                id: "MobyDick",
                title: "Moby Dick",
                callNumber: "PS4167. J3",
                category: "Fiction",
                shelfId: "FIC-2",
                description: "Herman Melville’s epic sea adventure tells the story of Captain Ahab’s obsessive quest to kill the great white whale, Moby Dick. Narrated by Ishmael, the novel explores themes of revenge, fate, and man’s struggle against nature. It is both a thrilling adventure and a deep philosophical meditation."
            ),
            Book(
                id: "JaneErye",
                title: "Jane Eyre",
                callNumber: "PS2384.M6",
                category: "Fiction",
                shelfId: "FIC-2",
                description: "Herman Melville’s epic sea adventure tells the story of Captain Ahab’s obsessive quest to kill the great white whale, Moby Dick. Narrated by Ishmael, the novel explores themes of revenge, fate, and man’s struggle against nature. It is both a thrilling adventure and a deep philosophical meditation."
            ),
            Book(
                id: "TheCatcherInTheErye",
                title: "The Catcher in the Rye",
                callNumber: "PS3537. A426 C3",
                category: "Fiction",
                shelfId: "FIC-2",
                description: "J.D. Salinger’s coming-of-age novel captures the disillusionment of postwar American youth through Holden Caulfield. After being expelled from prep school, Holden wanders New York City, struggling with alienation, loneliness, and the desire to protect childhood innocence from a corrupt adult world."
            ),

            // History (7)
            Book(
                id: "Sapiens",
                title: "Sapiens",
                callNumber: "CB113.H4 H37",
                category: "History",
                shelfId: "HIS-1",
                description: "Yuval Noah Harari traces the story of humankind from early hunter-gatherers to modern societies. Blending history, anthropology, and philosophy, he explains how Homo sapiens rose to dominance, shaped cultures, and created shared myths like religion and money. The book challenges readers to rethink what it means to be human."
            ),
            Book(
                id: "GunsGermsSteel",
                title: "Guns, Germs, and Steel",
                callNumber: "HM206.D53",
                category: "History",
                shelfId: "HIS-1",
                description: "Jared Diamond explores why some civilizations advanced more quickly than others. He argues that geography, access to domesticable animals, and environmental factors—not racial superiority—determined global power. The book explains how guns, infectious diseases, and technology shaped history."
            ),
            Book(
                id: "SilkRoads",
                title: "The Silk Roads",
                callNumber: "DS33.1.F73",
                category: "History",
                shelfId: "HIS-1",
                description: "Peter Frankopan retells world history from the perspective of Asia’s trade routes. From ancient empires to modern geopolitics, he shows how the East—not the West—was at the center of cultural exchange, economic power, and innovation. It shifts the focus of history back to the crossroads of civilizations."
            ),
            Book(
                id: "TeamRivals",
                title: "Team of Rivals",
                callNumber: "E457.2.G66",
                category: "History",
                shelfId: "HIS-1",
                description: "Doris Kearns Goodwin details Abraham Lincoln’s rise to the presidency and his bold decision to include political rivals in his cabinet. The book highlights Lincoln’s empathy, leadership, and ability to unite a divided nation during the Civil War. It’s both biography and study of statesmanship."
            ),
            Book(
                id: "WrightBrothers",
                title: "The Wright Brothers",
                callNumber: "TL540.W7 M38",
                category: "History",
                shelfId: "HIS-1",
                description: "David McCullough tells the inspiring story of Orville and Wilbur Wright, two bicycle makers from Ohio who defied the odds to invent the first powered airplane. Through determination, innovation, and resilience, the brothers changed human history forever."
            ),
            Book(
                id: "DiaryYoungGirl",
                title: "The Diary of a Young Girl",
                callNumber: "DS135.N6 F733",
                category: "History",
                shelfId: "HIS-2",
                description: "Anne Frank’s diary is a deeply moving first-hand account of life in hiding during the Nazi occupation of the Netherlands. Written between 1942 and 1944, it captures her fears, hopes, and reflections while living in secrecy. Her words have become a timeless symbol of courage and resilience."
            ),
            Book(
                id: "SecondWorldWar",
                title: "The Second World War",
                callNumber: "D743.C48",
                category: "History",
                shelfId: "HIS-2",
                description: "Winston Churchill recounts World War II from his perspective as Britain’s wartime Prime Minister. Spanning six volumes, it details military strategy, political decisions, and his leadership during one of history’s darkest times. It provides both a historical record and Churchill’s personal reflections."
            ),

            // Science (7)
            Book(
                id: "BriefHistoryTime",
                title: "A Brief History of Time",
                callNumber: "QH437.D38",
                category: "Science",
                shelfId: "SCI-1",
                description: "Stephen Hawking explains the mysteries of the universe, from black holes to the nature of time itself, in a way that’s accessible to readers without a science background. Blending cosmology and philosophy, he invites readers to think about humanity’s place in the cosmos."
            ),
            Book(
                id: "SelfishGene",
                title: "The Selfish Gene",
                callNumber: "QB44.2.S24",
                category: "Science",
                shelfId: "SCI-1",
                description: "Richard Dawkins revolutionized evolutionary biology with his idea that genes, not individuals, drive evolution. He explains natural selection in terms of “selfish” genes competing for survival, while also exploring altruism, cooperation, and culture as evolutionary strategies."
            ),
            Book(
                id: "Cosmos",
                title: "Cosmos",
                callNumber: "RB155.M85",
                category: "Science",
                shelfId: "SCI-1",
                description: "Carl Sagan takes readers on a grand tour of the universe, blending astronomy, history, and human imagination. He explores the origins of stars, planets, and life, while also warning about humanity’s responsibility to protect Earth. It’s a poetic tribute to science and wonder."
            ),
            Book(
                id: "TheGene",
                title: "The Gene",
                callNumber: "QB461.T97",
                category: "Science",
                shelfId: "SCI-1",
                description: "Siddhartha Mukherjee chronicles the history of genetics, from Mendel’s pea plants to modern breakthroughs in DNA sequencing. The book combines scientific explanation with personal stories and raises ethical questions about genetic engineering, identity, and the future of humanity."
            ),
            Book(
                id: "Astrophysics",
                title: "Astrophysics for People in a Hurry",
                callNumber: "QH545.P4 C3",
                category: "Science",
                shelfId: "SCI-2",
                description: "eil deGrasse Tyson delivers a fast-paced introduction to the universe’s biggest questions: dark matter, dark energy, black holes, and the origins of everything. Written with humor and clarity, it’s designed for readers curious about space but short on time."
            ),
            Book(
                id: "SilentSpring",
                title: "Silent Spring",
                callNumber: "QC174.26.S3 G74",
                category: "Science",
                shelfId: "SCI-2",
                description: "Rachel Carson’s groundbreaking book exposed the dangers of pesticides, particularly DDT, to ecosystems, wildlife, and human health. Her writing sparked the environmental movement and led to lasting changes in policy. It remains a powerful call to protect nature."
            ),
            Book(
                id: "ElegantUniverse",
                title: "The Elegant Universe",
                callNumber: "QC174.26.S3 G74",
                category: "Science",
                shelfId: "SCI-2",
                description: "Brian Greene introduces string theory as a possible “theory of everything” that unites general relativity and quantum mechanics. He explains complex physics through analogies, showing the beauty of hidden dimensions and the deep quest to understand the universe."
            )
        ]

        return LibraryData(image: image, youAreHere: youAreHere, shelves: shelves, books: books)
    }()
}
