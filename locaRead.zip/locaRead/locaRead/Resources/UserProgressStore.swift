import Foundation
import SwiftUI
import Combine

final class UserProgressStore: ObservableObject {
    // MARK: - History
    enum HistoryAction: String, Codable {
        case found
        case missing
        case read
    }

    struct HistoryEntry: Identifiable, Codable {
        let id: UUID
        let bookId: String
        let title: String
        let action: HistoryAction
        let exp: Int
        let date: Date
    }

    @Published private(set) var history: [HistoryEntry] = []

    // MARK: - Level/EXP
    @Published private(set) var level: Int
    @Published private(set) var expInLevel: Int

    // MARK: - Reading in Progress
    @Published private(set) var readingBookIDs: Set<String> = []

    func isReading(_ bookId: String) -> Bool {
        readingBookIDs.contains(bookId)
    }

    func startReading(bookId: String) {
        if !readingBookIDs.contains(bookId) {
            readingBookIDs.insert(bookId)
            save()
        }
    }

    // Finishing reading: award 50 XP and log "read" history
    func finishReading(bookId: String, title: String) {
        if let _ = readingBookIDs.remove(bookId) {
            _ = awardExp(50)
            addHistory(bookId: bookId, title: title, action: .read, exp: 50)
            save()
        }
    }

    // Required XP to go from current level -> next level:
    // Level 1→2: 100, 2→3: 150, 3→4: 200, ...
    func requiredExpToNextLevel(for level: Int) -> Int {
        max(50, 100 + (level - 1) * 50)
    }

    var requiredExpCurrentLevel: Int { requiredExpToNextLevel(for: level) }
    var expToNextLevel: Int { max(0, requiredExpCurrentLevel - expInLevel) }
    var progressFraction: Double {
        guard requiredExpCurrentLevel > 0 else { return 0 }
        return Double(expInLevel) / Double(requiredExpCurrentLevel)
    }

    // Award EXP; handle level-ups and carry over remainder
    @discardableResult
    func awardExp(_ amount: Int) -> (gainedLevels: Int, remainingExp: Int) {
        var remaining = max(0, amount)
        var levelsGained = 0

        while remaining > 0 {
            let need = requiredExpCurrentLevel - expInLevel
            if remaining >= need {
                remaining -= need
                level += 1
                expInLevel = 0
                levelsGained += 1
            } else {
                expInLevel += remaining
                remaining = 0
            }
        }

        save()
        return (levelsGained, remaining)
    }

    // Append a history entry (persisted)
    func addHistory(bookId: String, title: String, action: HistoryAction, exp: Int) {
        let entry = HistoryEntry(id: UUID(), bookId: bookId, title: title, action: action, exp: exp, date: Date())
        history.insert(entry, at: 0) // newest first
        save()
    }

    // MARK: - Persistence (UserDefaults)
    private let levelKey = "user.level"
    private let expKey = "user.expInLevel"
    private let historyKey = "user.history"
    private let readingKey = "user.readingBookIDs"

    init() {
        let storedLevel = UserDefaults.standard.integer(forKey: levelKey)
        let storedExp = UserDefaults.standard.integer(forKey: expKey)
        self.level = max(1, storedLevel == 0 ? 1 : storedLevel)
        self.expInLevel = max(0, storedExp)

        if let data = UserDefaults.standard.data(forKey: historyKey) {
            do {
                let decoded = try JSONDecoder().decode([HistoryEntry].self, from: data)
                self.history = decoded
            } catch {
                self.history = []
            }
        } else {
            self.history = []
        }

        if let arr = UserDefaults.standard.array(forKey: readingKey) as? [String] {
            self.readingBookIDs = Set(arr)
        } else {
            self.readingBookIDs = []
        }
    }

    private func save() {
        UserDefaults.standard.set(level, forKey: levelKey)
        UserDefaults.standard.set(expInLevel, forKey: expKey)
        if let data = try? JSONEncoder().encode(history) {
            UserDefaults.standard.set(data, forKey: historyKey)
        }
        UserDefaults.standard.set(Array(readingBookIDs), forKey: readingKey)
    }
}
