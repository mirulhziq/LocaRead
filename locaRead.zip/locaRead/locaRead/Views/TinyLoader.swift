import SwiftUI

struct TinyLoader: View {
    let message: String

    var body: some View {
        VStack {
            ProgressView()
                .progressViewStyle(.circular)
            Text(message)
                .font(.caption)
                .foregroundColor(.secondary)
        }
    }
}
