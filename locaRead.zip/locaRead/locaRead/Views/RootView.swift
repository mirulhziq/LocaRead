import SwiftUI

struct RootView: View {
    @EnvironmentObject var store: LibraryStore
    @EnvironmentObject var router: Router

    @State private var showWelcome = true

    var body: some View {
        ZStack {
            TabView {
                // Home tab with navigation
                NavigationStack(path: $router.path) {
                    Group {
                        if store.isLoading {
                            TinyLoader(message: "Loading…")
                        } else {
                            HomePage()
                        }
                    }
                    .navigationDestination(for: Route.self) { route in
                        switch route {
                        case .home:
                            HomePage()
                        case .searchResults(let q):
                            SearchResultsView(query: q)
                        case .bookDetail(let b):
                            BookDetailView(book: b)
                        case .map(let b):
                            MapView(book: b)
                        case .ar(let b):
                            if let shelf = store.shelf(for: b) {
                                ARGuideView(shelf: shelf, book: b)  // pass Book for history logging
                            } else {
                                Text("Shelf not found for this book.")
                            }
                        }
                    }
                }
                .tabItem {
                    Label("Home", systemImage: "house.fill")
                }

                // Profile tab
                NavigationStack {
                    ProfilePage()
                        .navigationBarTitleDisplayMode(.inline)
                }
                .tabItem {
                    Label("Profile", systemImage: "person.crop.circle")
                }
            }
            .disabled(showWelcome)

            if showWelcome {
                WelcomePage {
                    withAnimation(.easeInOut(duration: 0.4)) {
                        showWelcome = false
                    }
                }
                .transition(.opacity)
                .zIndex(1)
            }
        }
        .onAppear {
            if store.data == nil {
                store.loadFromBundle()
            }
        }
    }
}
