import SwiftUI

struct SearchResultsView: View {
    @EnvironmentObject var store: LibraryStore
    @EnvironmentObject var router: Router
    let query: String

    var body: some View {
        VStack {
            Text("Results for \"\(query)\"")
                .font(.headline)
                .padding()

            if store.searchResults.isEmpty {
                Spacer()
                Text("No results for '\(query)'")
                    .foregroundColor(.gray)
                Spacer()
            } else {
                List {
                    ForEach(store.searchResults) { book in
                        BookRow(book: book)
                            .onTapGesture {
                                router.path.append(.bookDetail(book: book))
                            }
                            .swipeActions(edge: .trailing, allowsFullSwipe: false) {
                                Button {
                                    router.path.append(.ar(book: book))
                                } label: {
                                    Label("AR", systemImage: "arkit")
                                }
                                .tint(.indigo)
                            }
                    }
                }
                .listStyle(.plain)
            }
        }
        .navigationTitle("Search Results")
        .navigationBarTitleDisplayMode(.inline)
    }
}
