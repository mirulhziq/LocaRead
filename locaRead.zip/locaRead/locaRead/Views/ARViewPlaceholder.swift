//
//  ARViewPlaceholder.swift
//  locaRead
//

import SwiftUI

struct ARViewPlaceholder: View {
    var body: some View {
        VStack(spacing: 16) {
            Image(systemName: "arkit")
                .font(.system(size: 48))
                .foregroundStyle(.secondary)
            Text("AR Not Available")
                .font(.title3).bold()
            Text("This device does not support ARKit world tracking.")
                .multilineTextAlignment(.center)
                .foregroundStyle(.secondary)
                .padding(.horizontal)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(.systemBackground))
    }
}
