import SwiftUI
import UIKit

struct ProfilePage: View {
    @EnvironmentObject var store: LibraryStore
    @EnvironmentObject var progress: UserProgressStore

    @State private var toastMessage: String? = nil

    var username: String = "Haziq Amirul"
    var studentID: String = "A1234567"
    var university: String = "University of Malaya"
    var faculty: String = "Faculty of Engineering"
    var courses: [String] = [
        "EEE453 - Transport Data Analysis",
        "CSE201 - Data Structures",
        "MAT202 - Linear Algebra"
    ]
    
    private var favouriteBooks: [Book] {
        guard let books = store.data?.books else { return [] }
        let favs = store.favoriteIDs
        return books.filter { favs.contains($0.id) }
    }

    private var readingBooks: [Book] {
        guard let books = store.data?.books else { return [] }
        let ids = progress.readingBookIDs
        return books.filter { ids.contains($0.id) }
    }

    var body: some View {
        ZStack(alignment: .top) {
            ScrollView {
                VStack(spacing: 30) {
                    ProfileHeaderCard(
                        username: username,
                        studentID: studentID,
                        university: university,
                        faculty: faculty
                    )
                    .padding(.horizontal)

                    // Reading in Progress (inserted between header and favourites)
                    ReadingInProgressSection(
                        books: readingBooks,
                        onFinish: { book in
                            progress.finishReading(bookId: book.id, title: book.title)
                            // Optional haptic + toast
                            let generator = UINotificationFeedbackGenerator()
                            generator.notificationOccurred(.success)
                            withAnimation(.spring(response: 0.4, dampingFraction: 0.9)) {
                                toastMessage = "Finished reading: \(book.title)"
                            }
                            DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) {
                                withAnimation(.easeInOut(duration: 0.25)) {
                                    toastMessage = nil
                                }
                            }
                        }
                    )
                    .padding(.horizontal)

                    FavouritesSection(
                        books: favouriteBooks,
                        onToggle: { book, wasFavoriteBefore in
                            // Haptic + toast with appropriate message
                            let generator = UINotificationFeedbackGenerator()
                            generator.notificationOccurred(.success)
                            withAnimation(.spring(response: 0.4, dampingFraction: 0.9)) {
                                toastMessage = wasFavoriteBefore ? "Removed from Favourite" : "Add to Favourite"
                            }
                            DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) {
                                withAnimation(.easeInOut(duration: 0.25)) {
                                    toastMessage = nil
                                }
                            }
                        }
                    )
                    .padding(.horizontal)

                    HistorySection()
                        .padding(.horizontal)

                    CoursesSection(courses: courses)
                        .padding(.horizontal)
                    
                    Spacer()
                }
                .padding(.top, 30)
            }

            // Top toast notification
            if let msg = toastMessage {
                ToastView(message: msg)
                    .transition(.move(edge: .top).combined(with: .opacity))
                    .padding(.top, 8)
            }
        }
        .background(Color(.systemGroupedBackground).ignoresSafeArea())
        .navigationTitle("Profile")
    }
}

// MARK: - Header Card
private struct ProfileHeaderCard: View {
    @EnvironmentObject var progress: UserProgressStore

    let username: String
    let studentID: String
    let university: String
    let faculty: String

    var body: some View {
        VStack(spacing: 15) {
            Image(systemName: "person.circle.fill")
                .resizable()
                .scaledToFit()
                .frame(width: 120, height: 120)
                .foregroundColor(.blue)
                .shadow(radius: 10)

            ExpBarView()
                .padding(.horizontal)

            Text(username)
                .font(.title)
                .fontWeight(.bold)
            
            Text("ID: \(studentID)")
                .font(.subheadline)
                .foregroundColor(.gray)
            
            Text(university)
                .font(.subheadline)
                .foregroundColor(.secondary)
            
            Text(faculty)
                .font(.subheadline)
                .foregroundColor(.secondary)
        }
        .padding()
        .frame(maxWidth: .infinity)
        .background(Color(.systemBackground))
        .cornerRadius(20)
        .shadow(color: .gray.opacity(0.3), radius: 10, x: 0, y: 5)
    }
}

// MARK: - Reading in Progress
private struct ReadingInProgressSection: View {
    let books: [Book]
    var onFinish: (Book) -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Reading in Progress")
                .font(.headline)
                .padding(.bottom, 5)

            if books.isEmpty {
                HStack {
                    Image(systemName: "book")
                        .foregroundColor(.secondary)
                    Text("No books in progress")
                        .foregroundColor(.secondary)
                }
                .padding(.vertical, 8)
            } else {
                ForEach(books) { book in
                    HStack(spacing: 12) {
                        if let ui = UIImage(named: book.id) {
                            Image(uiImage: ui)
                                .resizable()
                                .scaledToFill()
                                .frame(width: 40, height: 60)
                                .clipped()
                                .cornerRadius(6)
                        } else {
                            RoundedRectangle(cornerRadius: 6)
                                .fill(Color.gray.opacity(0.2))
                                .frame(width: 40, height: 60)
                                .overlay(
                                    Image(systemName: "text.book.closed.fill")
                                        .foregroundColor(.secondary)
                                )
                        }

                        VStack(alignment: .leading, spacing: 4) {
                            Text(book.title)
                                .font(.subheadline)
                                .fontWeight(.semibold)
                                .lineLimit(2)
                            Text(book.category)
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }

                        Spacer()

                        Button {
                            onFinish(book)
                        } label: {
                            Text("Finished Reading")
                                .font(.caption).bold()
                        }
                        .buttonStyle(.borderedProminent)
                        .controlSize(.small)
                        .accessibilityLabel("Mark \(book.title) as finished reading")
                    }
                    .padding(.vertical, 6)
                    Divider()
                }
            }
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(.systemBackground))
        .cornerRadius(20)
        .shadow(color: .gray.opacity(0.3), radius: 10, x: 0, y: 5)
    }
}

// MARK: - Favourites
private struct FavouritesSection: View {
    @EnvironmentObject var store: LibraryStore

    let books: [Book]
    var onToggle: (_ book: Book, _ wasFavoriteBefore: Bool) -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Favourites")
                .font(.headline)
                .padding(.bottom, 5)

            if books.isEmpty {
                HStack {
                    Image(systemName: "heart")
                        .foregroundColor(.pink)
                    Text("No favourites yet")
                        .foregroundColor(.secondary)
                }
                .padding(.vertical, 8)
            } else {
                ForEach(books) { book in
                    FavouriteRow(book: book) {
                        let wasFavorite = store.isFavorite(book)
                        store.toggleFavorite(book)
                        onToggle(book, wasFavorite)
                    }
                    Divider()
                }
            }
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(.systemBackground))
        .cornerRadius(20)
        .shadow(color: .gray.opacity(0.3), radius: 10, x: 0, y: 5)
    }
}

private struct FavouriteRow: View {
    @EnvironmentObject var store: LibraryStore
    let book: Book
    var onRemove: () -> Void

    private var uiImage: UIImage? { UIImage(named: book.id) }

    var body: some View {
        HStack(spacing: 12) {
            if let ui = uiImage {
                Image(uiImage: ui)
                    .resizable()
                    .scaledToFill()
                    .frame(width: 40, height: 60)
                    .clipped()
                    .cornerRadius(6)
            } else {
                RoundedRectangle(cornerRadius: 6)
                    .fill(Color.gray.opacity(0.2))
                    .frame(width: 40, height: 60)
                    .overlay(
                        Image(systemName: "text.book.closed.fill")
                            .foregroundColor(.secondary)
                    )
            }

            VStack(alignment: .leading, spacing: 4) {
                Text(book.title)
                    .font(.subheadline)
                    .fontWeight(.semibold)
                    .lineLimit(2)
                Text(book.category)
                    .font(.caption)
                    .foregroundColor(.secondary)
            }

            Spacer()

            Button {
                onRemove()
            } label: {
                Image(systemName: "heart.fill")
                    .foregroundColor(.red)
            }
            .buttonStyle(.plain)
            .accessibilityLabel("Remove \(book.title) from favourites")
        }
        .padding(.vertical, 6)
    }
}

// MARK: - History
private struct HistorySection: View {
    @EnvironmentObject var progress: UserProgressStore

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("History")
                .font(.headline)
                .padding(.bottom, 5)

            if progress.history.isEmpty {
                HStack {
                    Image(systemName: "clock")
                        .foregroundColor(.secondary)
                    Text("No activity yet")
                        .foregroundColor(.secondary)
                }
                .padding(.vertical, 8)
            } else {
                ForEach(progress.history) { entry in
                    HistoryRow(entry: entry)
                    Divider()
                }
            }
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(.systemBackground))
        .cornerRadius(20)
        .shadow(color: .gray.opacity(0.3), radius: 10, x: 0, y: 5)
    }
}

private struct HistoryRow: View {
    let entry: UserProgressStore.HistoryEntry

    private static let formatter: DateFormatter = {
        let df = DateFormatter()
        df.dateStyle = .medium
        df.timeStyle = .short
        return df
    }()

    private var iconName: String {
        switch entry.action {
        case .found: return "checkmark.seal.fill"
        case .missing: return "exclamationmark.triangle.fill"
        case .read: return "book.fill"
        }
    }
    private var iconColor: Color {
        switch entry.action {
        case .found: return .green
        case .missing: return .orange
        case .read: return .blue
        }
    }
    private var statusText: String {
        switch entry.action {
        case .found: return "Found"
        case .missing: return "Missing"
        case .read: return "Read"
        }
    }
    private var dateText: String {
        Self.formatter.string(from: entry.date)
    }

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: iconName)
                .foregroundColor(iconColor)
                .font(.system(size: 18))

            VStack(alignment: .leading, spacing: 2) {
                Text(entry.title)
                    .font(.subheadline)
                    .fontWeight(.semibold)
                    .lineLimit(2)

                HStack(spacing: 6) {
                    Text(statusText)
                        .font(.caption)
                        .foregroundColor(.secondary)
                    Text("• +\(entry.exp) XP")
                        .font(.caption)
                        .foregroundColor(.secondary)
                    Text("• \(dateText)")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            Spacer()
        }
        .padding(.vertical, 6)
    }
}

// MARK: - Courses
private struct CoursesSection: View {
    let courses: [String]

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Courses Attending")
                .font(.headline)
                .padding(.bottom, 5)
            
            ForEach(courses, id: \.self) { course in
                HStack {
                    Image(systemName: "book.closed.fill")
                        .foregroundColor(.blue)
                    Text(course)
                        .font(.body)
                }
                Divider()
            }
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(.systemBackground))
        .cornerRadius(20)
        .shadow(color: .gray.opacity(0.3), radius: 10, x: 0, y: 5)
    }
}

// MARK: - EXP Bar
private struct ExpBarView: View {
    @EnvironmentObject var progress: UserProgressStore

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text("Level \(progress.level)")
                    .font(.subheadline)
                    .fontWeight(.semibold)
                Spacer()
                Text("\(progress.expInLevel) / \(progress.requiredExpCurrentLevel) XP")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }

            GeometryReader { geo in
                let width = geo.size.width
                let pct = max(0.0, min(1.0, CGFloat(progress.progressFraction)))
                ZStack(alignment: .leading) {
                    RoundedRectangle(cornerRadius: 10)
                        .fill(Color.gray.opacity(0.2))
                        .frame(height: 12)

                    RoundedRectangle(cornerRadius: 10)
                        .fill(LinearGradient(colors: [.blue, .purple], startPoint: .leading, endPoint: .trailing))
                        .frame(width: width * pct, height: 12)
                        .animation(.easeInOut(duration: 0.35), value: pct)
                }
            }
            .frame(height: 12)

            Text("\(progress.expToNextLevel) XP to next level")
                .font(.caption2)
                .foregroundColor(.secondary)
        }
    }
}

// MARK: - Toast View (local to this file)
private struct ToastView: View {
    let message: String

    var body: some View {
        Text(message)
            .font(.subheadline).bold()
            .padding(.horizontal, 16)
            .padding(.vertical, 10)
            .background(.ultraThinMaterial)
            .clipShape(Capsule())
            .shadow(radius: 6)
    }
}

struct ProfilePage_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            ProfilePage()
                .environmentObject(LibraryStore())
                .environmentObject(UserProgressStore())
        }
    }
}
