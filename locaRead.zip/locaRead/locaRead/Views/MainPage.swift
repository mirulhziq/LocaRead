//
//  MainPage.swift
//  NoteNess
//
//  Created by STDC_35 on 19/09/2025.
//

import SwiftUI

struct MainPage: View {
    var body: some View {
        TabView{
            
            HomePage()
                .tabItem{
                    Label("Home", systemImage: "house.fill")
                        
}
            
            ProfilePage()
                .tabItem{
                   Label("profile", systemImage: "person.crop.circle")
                    
            }
        }
    }
}

#Preview {
    MainPage()
}
