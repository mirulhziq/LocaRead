//
//  ContentView.swift
//  NoteNess
//
//  Created by STDC_35 on 18/09/2025.
//

import SwiftUI

struct ContentView: View {
    @State private var showWelcome = true
    
    var body: some View {
        ZStack {
            
            MainPage()
                .opacity(showWelcome ? 0:1)
                .animation(.easeInOut(duration: 0.8), value: showWelcome)
            
            
            if showWelcome{
                WelcomePage()
                    .transition(.opacity)
                
            }
        }
        .onAppear{
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0){
            withAnimation(.easeInOut(duration: 1.0)){
                showWelcome = false
                }
            }
        }
    }
}
    #Preview {
        ContentView()
    }

