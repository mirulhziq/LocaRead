import SwiftUI
import UIKit

struct BookDetailView: View {
    @EnvironmentObject var store: LibraryStore
    @EnvironmentObject var router: Router
    @EnvironmentObject var progress: UserProgressStore
    let book: Book

    @State private var toastMessage: String? = nil

    var body: some View {
        ZStack(alignment: .top) {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    // Cover image on top with favourite button overlay
                    HStack {
                        Spacer()
                        coverView(for: book)
                            .overlay(alignment: .topTrailing) {
                                FavoriteOverlayButton(book: book) { isNowFavorite in
                                    // Haptic + toast
                                    let generator = UINotificationFeedbackGenerator()
                                    generator.notificationOccurred(.success)

                                    withAnimation(.spring(response: 0.4, dampingFraction: 0.9)) {
                                        toastMessage = isNowFavorite ? "Add to Favourite" : "Removed from Favourite"
                                    }
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) {
                                        withAnimation(.easeInOut(duration: 0.25)) {
                                            toastMessage = nil
                                        }
                                    }
                                }
                                .padding(8)
                            }
                            .accessibilityLabel("Cover image for \(book.title)")
                        Spacer()
                    }
                    .padding(.top, 8)
                    .padding(.bottom, 12) // Extra padding between image and title

                    // Title
                    Text(book.title)
                        .font(.largeTitle)
                        .fontWeight(.bold)

                    // Key details
                    DetailRow(label: "Category", value: book.category)
                    DetailRow(label: "Call Number", value: book.callNumber)

                    if let shelf = store.shelf(for: book) {
                        // Show data exactly as defined in BookData
                        DetailRow(label: "Shelf ID", value: shelf.id)
                        DetailRow(label: "Shelf Label", value: shelf.label)
                        DetailRow(label: "Floor", value: "\(shelf.floor)")
                    } else {
                        DetailRow(label: "Shelf", value: "Unknown shelf")
                    }

                    Divider()

                    // Description
                    Text("Description")
                        .font(.headline)
                    Text(book.description)
                        .font(.body)

                    // Actions
                    VStack(spacing: 10) {
                        // Open Map (prominent filled style)
                        Button("Open Map") {
                            router.path.append(.map(book: book))
                        }
                        .font(.headline)
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                        .background(
                            RoundedRectangle(cornerRadius: 12)
                                .fill(Color.accentColor)
                        )

                        // Open AR View: blue when not reading, muted gray when currently reading
                        let isReading = progress.isReading(book.id)
                        Button("Open AR View") {
                            if isReading {
                                // Block AR while reading; show a quick toast
                                let generator = UINotificationFeedbackGenerator()
                                generator.notificationOccurred(.warning)
                                withAnimation(.spring(response: 0.4, dampingFraction: 0.9)) {
                                    toastMessage = "This book is currently being read."
                                }
                                DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) {
                                    withAnimation(.easeInOut(duration: 0.25)) {
                                        toastMessage = nil
                                    }
                                }
                            } else {
                                router.path.append(.ar(book: book))
                            }
                        }
                        .font(.headline)
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                        .background(
                            RoundedRectangle(cornerRadius: 12)
                                .fill(isReading ? Color.gray.opacity(0.6) : Color.blue)
                        )
                    }
                    .padding(.top, 8)
                }
                .padding()
            }

            // Top toast notification
            if let msg = toastMessage {
                ToastView(message: msg)
                    .transition(.move(edge: .top).combined(with: .opacity))
                    .padding(.top, 8)
            }
        }
        .navigationTitle("Book Details")
        .navigationBarTitleDisplayMode(.inline)
    }

    // MARK: - Cover
    @ViewBuilder
    private func coverView(for book: Book) -> some View {
        if let uiImage = UIImage(named: book.id) {
            Image(uiImage: uiImage)
                .resizable()
                .scaledToFit()
                .frame(maxWidth: 260) // Tweak to taste
                .aspectRatio(2/3, contentMode: .fit)
                .clipShape(RoundedRectangle(cornerRadius: 12))
                .shadow(radius: 6)
        } else {
            ZStack {
                RoundedRectangle(cornerRadius: 12)
                    .fill(Color.gray.opacity(0.15))
                    .frame(width: 260, height: 390) // 2:3 aspect (260×390)
                    .shadow(radius: 4)

                Image(systemName: "text.book.closed.fill")
                    .font(.system(size: 48))
                    .foregroundColor(.accentColor)
            }
        }
    }

    // MARK: - Detail Row
    private struct DetailRow: View {
        let label: String
        let value: String

        var body: some View {
            HStack(alignment: .firstTextBaseline, spacing: 8) {
                Text("\(label):")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                Text(value)
                    .font(.subheadline)
            }
        }
    }
}

// MARK: - Favourite Button Overlay (red when favourited) with callback
private struct FavoriteOverlayButton: View {
    @EnvironmentObject var store: LibraryStore
    let book: Book
    var onToggle: (Bool) -> Void // isNowFavorite

    var body: some View {
        Button(action: {
            let willFavorite = !store.isFavorite(book)
            store.toggleFavorite(book)
            onToggle(willFavorite)
        }) {
            Image(systemName: store.isFavorite(book) ? "heart.fill" : "heart")
                .font(.system(size: 16, weight: .semibold))
                .foregroundColor(store.isFavorite(book) ? .red : .white)
                .padding(9)
                .background(
                    Circle()
                        .fill(store.isFavorite(book) ? Color.white : Color.indigo)
                )
                .shadow(radius: 3)
        }
        .buttonStyle(.plain)
        .accessibilityLabel((store.isFavorite(book) ? "Remove from" : "Add to") + " favourites for \(book.title)")
    }
}

// MARK: - Toast View (simple capsule)
private struct ToastView: View {
    let message: String

    var body: some View {
        Text(message)
            .font(.subheadline).bold()
            .padding(.horizontal, 16)
            .padding(.vertical, 10)
            .background(.ultraThinMaterial)
            .clipShape(Capsule())
            .shadow(radius: 6)
    }
}
