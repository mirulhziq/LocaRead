import SwiftUI

struct BookRow: View {
    let book: Book

    var body: some View {
        HStack(spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 6)
                    .fill(Color.gray.opacity(0.15))
                    .frame(width: 44, height: 66)

                if let uiImage = coverUIImage(for: book) {
                    Image(uiImage: uiImage)
                        .resizable()
                        .scaledToFill()
                        .frame(width: 44, height: 66)
                        .clipped()
                        .clipShape(RoundedRectangle(cornerRadius: 6))
                } else {
                    Image(systemName: "text.book.closed.fill")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 22, height: 22)
                        .foregroundColor(.accentColor)
                }
            }

            VStack(alignment: .leading) {
                Text(book.title)
                    .font(.headline)
                    .lineLimit(1)
                Text(book.category)
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .lineLimit(1)
                Text(book.callNumber)
                    .font(.caption)
                    .foregroundColor(.secondary)
                    .lineLimit(1)
            }
            Spacer()
            Image(systemName: "chevron.right")
                .foregroundColor(.gray)
        }
        .padding(.vertical, 6)
    }

    // Minimal resolver: id, id without underscores, title condensed/underscored, and lowercased variants
    private func coverUIImage(for book: Book) -> UIImage? {
        for name in candidateAssetNames(for: book) {
            if let img = UIImage(named: name) { return img }
        }
        return nil
    }

    private func candidateAssetNames(for book: Book) -> [String] {
        let id = book.id
        let rawTitle = book.title

        let idNoUnderscore = id.replacingOccurrences(of: "_", with: "")
        let titleUnderscored = rawTitle.replacingOccurrences(of: " ", with: "_")
        let titleCondensed = rawTitle.replacingOccurrences(of: " ", with: "")

        var names: [String] = [
            id,
            idNoUnderscore,
            rawTitle,
            titleUnderscored,
            titleCondensed
        ]

        // Lowercased variants
        names += names.map { $0.lowercased() }

        // Deduplicate while preserving order
        var seen = Set<String>()
        return names.filter { seen.insert($0).inserted }
    }
}
