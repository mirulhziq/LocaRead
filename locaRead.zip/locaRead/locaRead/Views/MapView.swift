import SwiftUI
import UIKit

struct MapView: View {
    @EnvironmentObject var store: LibraryStore
    @EnvironmentObject var router: Router
    @EnvironmentObject var progress: UserProgressStore
    let book: Book

    @State private var toastMessage: String? = nil

    // Floor 2 entrance (bottom-center) from your Floor 2 image
    private let floor2YouAreHere = CGPoint(x: 500, y: 520)

    var body: some View {
        ZStack(alignment: .top) {
            VStack {
                if let libraryData = store.data, let shelf = store.shelf(for: book) {
                    GeometryReader { geometry in
                        // Choose image and you-are-here per floor
                        let isFloor2 = (shelf.floor == 2)
                        let imageName = isFloor2 ? "floor_map_2" : "floor_map"

                        Image(imageName)
                            .resizable()
                            .scaledToFit()
                            .frame(width: geometry.size.width, height: geometry.size.height)
                            .overlay(
                                ZStack(alignment: .topTrailing) {
                                    // You Are Here pin
                                    let yahPoint = isFloor2
                                        ? floor2YouAreHere
                                        : CGPoint(x: libraryData.youAreHere.x, y: libraryData.youAreHere.y)
                                    let youAreHereX = (yahPoint.x / libraryData.image.width) * geometry.size.width
                                    let youAreHereY = (yahPoint.y / libraryData.image.height) * geometry.size.height

                                    Image(systemName: "person.fill.viewfinder")
                                        .font(.title)
                                        .foregroundColor(.blue)
                                        .position(x: youAreHereX, y: youAreHereY)
                                        .accessibilityLabel("You are here")

                                    // Target Shelf pin
                                    let targetShelfX = (shelf.x / libraryData.image.width) * geometry.size.width
                                    let targetShelfY = (shelf.y / libraryData.image.height) * geometry.size.height

                                    Image(systemName: "mappin.and.ellipse")
                                        .font(.title)
                                        .foregroundColor(.red)
                                        .position(x: targetShelfX, y: targetShelfY)
                                        .accessibilityLabel("Target shelf: \(shelf.label)")

                                    // Beautified Legend (top-right)
                                    LegendCard()
                                        .padding(12)
                                }
                            )
                    }
                } else {
                    Text("Map data not available.")
                }

                // Visual block indicator (but still tappable to show toast)
                let isBlocked = progress.isReading(book.id)

                Button("Start AR Navigation") {
                    if isBlocked {
                        // Block AR while reading — show a warning toast
                        let generator = UINotificationFeedbackGenerator()
                        generator.notificationOccurred(.warning)
                        withAnimation(.spring(response: 0.4, dampingFraction: 0.9)) {
                            toastMessage = "The book is currently reading"
                        }
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) {
                            withAnimation(.easeInOut(duration: 0.25)) {
                                toastMessage = nil
                            }
                        }
                    } else {
                        router.path.append(.ar(book: book))
                    }
                }
                .buttonStyle(.borderedProminent)
                .tint(isBlocked ? .gray : .blue)          // subtle style tweak when blocked
                .opacity(isBlocked ? 0.85 : 1.0)          // slight dimming when blocked
                .animation(.easeInOut(duration: 0.2), value: isBlocked)
                .controlSize(.large)
                .frame(maxWidth: .infinity)
                .padding()
                .accessibilityHint(isBlocked ? "Finish reading this book to enable AR again." : "Start AR guidance to the shelf.")
            }

            // Top toast notification
            if let msg = toastMessage {
                ToastView(message: msg)
                    .transition(.move(edge: .top).combined(with: .opacity))
                    .padding(.top, 8)
            }
        }
        .navigationTitle("Floor Map")
        .navigationBarTitleDisplayMode(.inline)
    }
}

// MARK: - Legend UI

private struct LegendCard: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Legend")
                .font(.headline)
                .fontWeight(.semibold)

            LegendRow(icon: "person.fill.viewfinder", color: .blue, label: "You Are Here")
            LegendRow(icon: "mappin.and.ellipse", color: .red, label: "Target Shelf")
        }
        .padding(12)
        .background(
            // High-contrast, blur-backed card that adapts to Light/Dark Mode
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .fill(.ultraThinMaterial)
        )
        .overlay(
            // Subtle border for extra separation over bright areas
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .stroke(Color.primary.opacity(0.15), lineWidth: 1)
        )
        .shadow(color: Color.black.opacity(0.15), radius: 10, x: 0, y: 6)
        .accessibilityElement(children: .combine)
        .accessibilityLabel("Legend: Blue icon is You Are Here. Red pin is Target Shelf.")
    }
}

private struct LegendRow: View {
    let icon: String
    let color: Color
    let label: String

    var body: some View {
        HStack(spacing: 10) {
            ZStack {
                Circle()
                    .fill(color.opacity(0.18))   // tinted chip background for visibility
                    .frame(width: 28, height: 28)
                Image(systemName: icon)
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(color)
            }
            Text(label)
                .font(.subheadline)
        }
    }
}

// MARK: - Toast View (local)
private struct ToastView: View {
    let message: String

    var body: some View {
        Text(message)
            .font(.subheadline).bold()
            .padding(.horizontal, 16)
            .padding(.vertical, 10)
            .background(.ultraThinMaterial)
            .clipShape(Capsule())
            .shadow(radius: 6)
    }
}
