//  ARGuideView.swift
//  locaRead
//
//  Floor-anchored indoor AR breadcrumbs to a shelf
//  Uses ARReferenceImage for deterministic anchoring
//  Requires: RealityKit, ARKit, iOS 16+

import SwiftUI
import RealityKit
import ARKit
import simd
import Combine
import UIKit

struct ARGuideView: UIViewRepresentable {
    @EnvironmentObject var store: LibraryStore
    @EnvironmentObject var router: Router
    @EnvironmentObject var progress: UserProgressStore   // Award XP + log history
    let shelf: Shelf
    let book: Book                                       // which book we’re guiding to

    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }

    func makeUIView(context: Context) -> ARView {
        let arView = ARView(frame: .zero)
        arView.automaticallyConfigureSession = false
        arView.environment.sceneUnderstanding.options.insert(.occlusion)

        // 1) World tracking + image detection
        let config = ARWorldTrackingConfiguration()
        config.planeDetection = [.horizontal]
        config.environmentTexturing = .automatic
        config.worldAlignment = .gravity

        if let refImages = ARReferenceImage.referenceImages(inGroupNamed: context.coordinator.referenceGroupName, bundle: .main) {
            config.detectionImages = refImages
            config.maximumNumberOfTrackedImages = 1
        } else {
            print("ARGuideView: No AR Reference Images found in group '\(context.coordinator.referenceGroupName)'.")
        }

        arView.session.delegate = context.coordinator
        arView.session.run(config, options: [.resetTracking, .removeExistingAnchors])

        // 2) Coaching overlay
        let coaching = ARCoachingOverlayView()
        coaching.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        coaching.goal = .horizontalPlane
        coaching.session = arView.session
        coaching.activatesAutomatically = true
        arView.addSubview(coaching)

        // 3) Tap to set origin (fallback)
        let tap = UITapGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.handleTap(_:)))
        arView.addGestureRecognizer(tap)

        // 4) Scene roots
        context.coordinator.arView = arView
        context.coordinator.setupRoots()

        // 5) Live updates
        context.coordinator.sceneSub = arView.scene.subscribe(to: SceneEvents.Update.self) { _ in
            context.coordinator.updateBreadcrumbs()
            context.coordinator.updateBeaconEffects()
        }

        // 6) UI overlays (Finish button + Missing Book + toast)
        context.coordinator.installOverlays(on: arView)

        // 7) Preload visual/audio assets (optional)
        context.coordinator.preloadAssets()

        return arView
    }

    func updateUIView(_ uiView: ARView, context: Context) {
        context.coordinator.destinationShelf = shelf
        context.coordinator.refreshDestinationVisuals()
    }

    final class Coordinator: NSObject, ARSessionDelegate {
        var parent: ARGuideView
        weak var arView: ARView?

        // Anchors/entities
        var originAnchor = AnchorEntity()
        var breadcrumbsAnchor = AnchorEntity()
        var youAreHereEntity: ModelEntity?
        var shelfPillarEntity: ModelEntity?
        var shelfLabelEntity: ModelEntity?

        // Visual polish assets
        var arrowTemplate: ModelEntity?                 // USDZ arrow (optional)
        var beaconEntity: Entity?                       // rotating/glowing beacon at target
        var beaconAudioResource: AudioFileResource?     // optional ping audio
        var beaconAudioController: AudioPlaybackController?
        let beaconRotationSpeed: Float = 0.8            // radians per second

        // Data
        var destinationShelf: Shelf
        var headingRadians: Float = 0
        var sceneSub: (any Cancellable)?
        private var hasPlacedOnce = false

        // Reference image config
        let referenceGroupName = "AR Resources"
        var targetImageName: String? {
            destinationShelf.floor == 1 ? "entrance_maker" : "entrance_maker2"
        }

        // Optional map rotation tweak
        let mapRotationRadians: Float = 0

        // Tuning
        let arrowStep: Float = 0.5
        let arrowHeight: Float = 0.04
        let arrowCountMax = 30

        // Map units → AR meters
        let scaleX: Float = 0.005
        let scaleY: Float = 0.005

        // Per-floor "You Are Here" in map units
        let floor1Origin = CGPoint(x: 120, y: 520)  // from BookData
        let floor2Origin = CGPoint(x: 500, y: 520)  // from Floor 2 map

        // UI overlays
        weak var finishButton: UIButton?
        weak var missingButton: UIButton?
        weak var toastView: UIView?
        weak var toastLabel: UILabel?

        init(_ parent: ARGuideView) {
            self.parent = parent
            self.destinationShelf = parent.shelf
            super.init()
        }

        func setupRoots() {
            guard let arView else { return }
            arView.scene.anchors.append(originAnchor)
            arView.scene.anchors.append(breadcrumbsAnchor)
        }

        // MARK: - Asset preload (visual/audio)
        func preloadAssets() {
            // Prefer your original USDZ arrow if present
            if let model = try? Entity.loadModel(named: "Arrow") {
                arrowTemplate = model
            } else if let model = try? Entity.loadModel(named: "arrow") {
                arrowTemplate = model
            } else {
                arrowTemplate = nil
                print("ARGuideView: USDZ arrow not found; using fallback arrow.")
            }

            // Try to load a looping spatial audio beacon (optional)
            if let res = try? AudioFileResource.load(named: "beacon_ping",
                                                     in: nil,
                                                     inputMode: .spatial,
                                                     loadingStrategy: .preload,
                                                     shouldLoop: true) {
                beaconAudioResource = res
            } else {
                beaconAudioResource = nil
            }
        }

        // MARK: - UI Overlays
        func installOverlays(on arView: ARView) {
            // Finish button (hidden until first placement)
            let finish = UIButton(type: .system)
            finish.setTitle("Finish", for: .normal)
            finish.titleLabel?.font = .systemFont(ofSize: 17, weight: .semibold)
            finish.backgroundColor = UIColor.systemBlue
            finish.tintColor = .white
            finish.layer.cornerRadius = 12
            finish.contentEdgeInsets = UIEdgeInsets(top: 10, left: 18, bottom: 10, right: 18)
            finish.addTarget(self, action: #selector(finishTapped), for: .touchUpInside)
            finish.translatesAutoresizingMaskIntoConstraints = false
            finish.alpha = 0 // hidden initially
            arView.addSubview(finish)
            NSLayoutConstraint.activate([
                finish.centerXAnchor.constraint(equalTo: arView.safeAreaLayoutGuide.centerXAnchor),
                finish.bottomAnchor.constraint(equalTo: arView.safeAreaLayoutGuide.bottomAnchor, constant: -20)
            ])
            self.finishButton = finish

            // Missing Book button (always visible)
            let missing = UIButton(type: .system)
            missing.setTitle("Missing Book", for: .normal)
            missing.titleLabel?.font = .systemFont(ofSize: 15, weight: .semibold)
            missing.backgroundColor = UIColor.systemRed
            missing.tintColor = .white
            missing.layer.cornerRadius = 12
            missing.contentEdgeInsets = UIEdgeInsets(top: 8, left: 14, bottom: 8, right: 14)
            missing.addTarget(self, action: #selector(missingTapped), for: .touchUpInside)
            missing.translatesAutoresizingMaskIntoConstraints = false
            arView.addSubview(missing)
            NSLayoutConstraint.activate([
                missing.leadingAnchor.constraint(equalTo: arView.safeAreaLayoutGuide.leadingAnchor, constant: 20),
                missing.bottomAnchor.constraint(equalTo: arView.safeAreaLayoutGuide.bottomAnchor, constant: -20)
            ])
            self.missingButton = missing

            // Toast card (center)
            let blur = UIVisualEffectView(effect: UIBlurEffect(style: .systemThickMaterial))
            blur.layer.cornerRadius = 16
            blur.clipsToBounds = true
            blur.translatesAutoresizingMaskIntoConstraints = false

            let label = UILabel()
            label.text = "" // set on finish/missing
            label.font = .systemFont(ofSize: 16, weight: .semibold)
            label.numberOfLines = 0
            self.toastLabel = label

            let stack = UIStackView(arrangedSubviews: [label])
            stack.axis = .horizontal
            stack.alignment = .center
            stack.spacing = 10
            stack.translatesAutoresizingMaskIntoConstraints = false

            blur.contentView.addSubview(stack)
            NSLayoutConstraint.activate([
                stack.topAnchor.constraint(equalTo: blur.contentView.topAnchor, constant: 14),
                stack.bottomAnchor.constraint(equalTo: blur.contentView.bottomAnchor, constant: -14),
                stack.leadingAnchor.constraint(equalTo: blur.contentView.leadingAnchor, constant: 16),
                stack.trailingAnchor.constraint(equalTo: blur.contentView.trailingAnchor, constant: -16),
            ])

            arView.addSubview(blur)
            NSLayoutConstraint.activate([
                blur.centerXAnchor.constraint(equalTo: arView.safeAreaLayoutGuide.centerXAnchor),
                blur.centerYAnchor.constraint(equalTo: arView.safeAreaLayoutGuide.centerYAnchor, constant: -40),
                blur.widthAnchor.constraint(lessThanOrEqualTo: arView.widthAnchor, multiplier: 0.9)
            ])

            blur.alpha = 0
            blur.transform = CGAffineTransform(scaleX: 0.85, y: 0.85)
            self.toastView = blur
        }

        private func revealFinishButton() {
            guard let btn = finishButton else { return }
            if btn.alpha == 0 {
                UIView.animate(withDuration: 0.25) { btn.alpha = 1 }
            }
        }

        private func showToastThenExit(popToRoot: Bool = false) {
            guard let arView, let toast = toastView else { return }

            let generator = UINotificationFeedbackGenerator()
            generator.notificationOccurred(.success)

            toast.alpha = 0
            toast.transform = CGAffineTransform(scaleX: 0.85, y: 0.85)
            arView.bringSubviewToFront(toast)
            UIView.animate(withDuration: 0.35, delay: 0, usingSpringWithDamping: 0.9, initialSpringVelocity: 0.8) {
                toast.alpha = 1
                toast.transform = .identity
            } completion: { _ in
                UIView.animate(withDuration: 0.3, delay: 1.2) {
                    toast.alpha = 0
                } completion: { _ in
                    DispatchQueue.main.async {
                        if popToRoot {
                            self.parent.router.popToRoot()
                        } else if !self.parent.router.path.isEmpty {
                            self.parent.router.path.removeLast()
                        }
                    }
                }
            }
        }

        // MARK: - ARSessionDelegate (Image detection)
        func session(_ session: ARSession, didAdd anchors: [ARAnchor]) {
            for anchor in anchors {
                guard let imageAnchor = anchor as? ARImageAnchor else { continue }
                if let targetName = targetImageName, imageAnchor.referenceImage.name != targetName {
                    continue
                }
                placeOrigin(from: imageAnchor)
                hasPlacedOnce = true
                revealFinishButton()
                break
            }
        }

        private func placeOrigin(from imageAnchor: ARImageAnchor) {
            guard let arView else { return }
            let newOrigin = AnchorEntity(anchor: imageAnchor)
            originAnchor.removeFromParent()
            arView.scene.addAnchor(newOrigin)
            originAnchor = newOrigin

            headingRadians = mapRotationRadians
            placeYouAreHere()
            refreshDestinationVisuals()
        }

        // MARK: - Tap fallback (or manual placement)
        @objc func handleTap(_ recognizer: UITapGestureRecognizer) {
            guard let arView else { return }
            let point = recognizer.location(in: arView)

            let primary = arView.raycast(from: point, allowing: .existingPlaneGeometry, alignment: .horizontal)
            let results = primary.isEmpty
                ? arView.raycast(from: point, allowing: .estimatedPlane, alignment: .horizontal)
                : primary
            guard let hit = results.first else { return }

            let newOrigin = AnchorEntity(raycastResult: hit)
            originAnchor.removeFromParent()
            arView.scene.addAnchor(newOrigin)
            originAnchor = newOrigin

            if let camT = arView.session.currentFrame?.camera.transform {
                headingRadians = cameraYawRadians(camT) + mapRotationRadians
            } else {
                headingRadians = mapRotationRadians
            }

            placeYouAreHere()
            refreshDestinationVisuals()

            hasPlacedOnce = true
            revealFinishButton()
        }

        // MARK: - Visuals
        func placeYouAreHere() {
            youAreHereEntity?.removeFromParent()
            let disk = MeshResource.generateCylinder(height: 0.01, radius: 0.10)
            let mat = SimpleMaterial(color: .blue, isMetallic: false)
            let e = ModelEntity(mesh: disk, materials: [mat])
            e.position = SIMD3<Float>(0, arrowHeight/2, 0)
            originAnchor.addChild(e)
            youAreHereEntity = e
        }

        func refreshDestinationVisuals() {
            // Remove old visuals
            shelfPillarEntity?.removeFromParent()
            shelfLabelEntity?.removeFromParent()
            beaconEntity?.removeFromParent()
            beaconAudioController = nil

            // Compute target local position (keep existing math)
            let destLocal = destinationLocalMeters()
            let rotated = rotateAroundY(destLocal, by: headingRadians)

            // Yellow pillar (visual indicator)
            let pillar = MeshResource.generateBox(size: SIMD3<Float>(0.12, 1.2, 0.12))
            let pillarMat = SimpleMaterial(color: .yellow, isMetallic: false)
            let pillarEntity = ModelEntity(mesh: pillar, materials: [pillarMat])
            pillarEntity.position = SIMD3<Float>(rotated.x, 0.6, rotated.z)
            originAnchor.addChild(pillarEntity)
            shelfPillarEntity = pillarEntity

            // Floating label (billboard)
            let textMesh = MeshResource.generateText(
                destinationShelf.category,
                extrusionDepth: 0.01,
                font: .systemFont(ofSize: 0.25, weight: .bold),
                containerFrame: .zero,
                alignment: .center,
                lineBreakMode: .byWordWrapping
            )
            let textMat = SimpleMaterial(color: .black, isMetallic: false)
            let textEntity = ModelEntity(mesh: textMesh, materials: [textMat])
            textEntity.position = SIMD3<Float>(rotated.x, 1.5, rotated.z)
            textEntity.components.set(BillboardComponent())
            originAnchor.addChild(textEntity)
            shelfLabelEntity = textEntity

            // Simple rotating beacon halo (no PBR/emissive to avoid API differences)
            setupBeacon(at: rotated)

            // Breadcrumbs
            updateBreadcrumbs()
        }

        private func setupBeacon(at localPosition: SIMD3<Float>) {
            // Thin disc above the pillar
            let haloMesh = MeshResource.generateCylinder(height: 0.02, radius: 0.25)
            let haloMat = SimpleMaterial(color: UIColor.cyan.withAlphaComponent(0.75), isMetallic: false)
            let halo = ModelEntity(mesh: haloMesh, materials: [haloMat])
            halo.position = SIMD3<Float>(localPosition.x, 1.8, localPosition.z)

            let root = Entity()
            root.addChild(halo)
            originAnchor.addChild(root)
            beaconEntity = root

            // Start spatial audio (if available)
            if let res = beaconAudioResource, beaconAudioController == nil {
                beaconAudioController = root.playAudio(res)
                beaconAudioController?.gain = 0.0 // start quiet; will update with distance
            }
        }

        func updateBreadcrumbs() {
            guard let arView else { return }
            guard let camTransform = arView.session.currentFrame?.camera.transform else { return }
            guard youAreHereEntity != nil else { return }

            let destLocal = destinationLocalMeters()
            let rotated = rotateAroundY(destLocal, by: headingRadians)
            let destWorld = (originAnchor.transform.matrix * SIMD4<Float>(rotated.x, rotated.y, rotated.z, 1)).xyz

            let camPos4 = camTransform.columns.3
            let camPos = SIMD3<Float>(camPos4.x, camPos4.y, camPos4.z)
            let start = SIMD3<Float>(camPos.x, destWorld.y, camPos.z)

            breadcrumbsAnchor.children.removeAll()

            let toDest = destWorld - start
            let total = simd_length(toDest)
            guard total > 0.001 else { return }
            let dir = simd_normalize(toDest)
            let steps = min(Int(total / arrowStep), arrowCountMax)

            if steps > 0 {
                for i in 1...steps {
                    let p = start + dir * (Float(i) * arrowStep)
                    let yaw = atan2f(dir.x, dir.z)
                    let arrow = makeArrow(heading: yaw)
                    arrow.position = SIMD3<Float>(p.x, p.y + arrowHeight/2, p.z)
                    breadcrumbsAnchor.addChild(arrow)
                }
            }
        }

        // Rotate beacon + update audio gain based on distance (visual/audio only)
        func updateBeaconEffects() {
            guard let arView, let beaconEntity else { return }
            // Rotate the beacon's halo
            let dt: Float = 1.0 / 60.0 // approx; RealityKit doesn't pass dt here
            beaconEntity.orientation *= simd_quatf(angle: beaconRotationSpeed * dt, axis: SIMD3<Float>(0, 1, 0))

            // Update audio volume by distance (if playing)
            guard let ctrl = beaconAudioController else { return }
            guard let camT = arView.session.currentFrame?.camera.transform else { return }

            let destLocal = destinationLocalMeters()
            let rotated = rotateAroundY(destLocal, by: headingRadians)
            let destWorld = (originAnchor.transform.matrix * SIMD4<Float>(rotated.x, rotated.y, rotated.z, 1)).xyz

            let camPos4 = camT.columns.3
            let camPos = SIMD3<Float>(camPos4.x, camPos4.y, camPos4.z)
            let distance = simd_length(destWorld - camPos)

            // Map distance to gain (closer = louder). Tweak maxRange to taste.
            let maxRange: Float = 12.0
            let gainLinear = max(0.0, 1.0 - min(distance, maxRange) / maxRange)
            ctrl.gain = Double(gainLinear)
        }

        private func makeArrow(heading: Float) -> Entity {
            // Prefer the USDZ arrow if available; otherwise fallback to the box arrow
            if let template = arrowTemplate {
                let root = Entity()
                let arrow = template.clone(recursive: true)
                // Make it clearly visible
                arrow.scale = SIMD3<Float>(repeating: 0.35)
                root.orientation = simd_quatf(angle: heading, axis: SIMD3<Float>(0, 1, 0))
                root.addChild(arrow)
                return root
            } else {
                // Fallback: cyan box arrow (simple material)
                let root = Entity()
                let mat = SimpleMaterial(color: .cyan, isMetallic: false)

                let shaftMesh = MeshResource.generateBox(size: SIMD3<Float>(0.025, 0.02, 0.16))
                let shaft = ModelEntity(mesh: shaftMesh, materials: [mat])

                let headMesh = MeshResource.generateBox(size: SIMD3<Float>(0.05, 0.02, 0.07))
                let head = ModelEntity(mesh: headMesh, materials: [mat])
                head.position = SIMD3<Float>(0, 0, 0.11)

                root.orientation = simd_quatf(angle: heading, axis: SIMD3<Float>(0, 1, 0))
                root.addChild(shaft)
                root.addChild(head)
                return root
            }
        }

        private func rotateAroundY(_ v: SIMD3<Float>, by angle: Float) -> SIMD3<Float> {
            let c = cos(angle), s = sin(angle)
            return SIMD3<Float>(c*v.x + s*v.z, v.y, -s*v.x + c*v.z)
        }

        // Convert shelf position to local meters relative to the correct floor origin
        private func destinationLocalMeters() -> SIMD3<Float> {
            let origin: CGPoint = {
                if destinationShelf.floor == 2 {
                    return floor2Origin
                } else if let data = parent.store.data {
                    return CGPoint(x: data.youAreHere.x, y: data.youAreHere.y)
                } else {
                    return floor1Origin
                }
            }()

            let dxUnits = Float(destinationShelf.x) - Float(origin.x)
            let dyUnits = Float(destinationShelf.y) - Float(origin.y)

            let dx = dxUnits * scaleX
            let dz = -dyUnits * scaleY // map +Y down → AR −Z forward
            return SIMD3<Float>(dx, 0, dz)
        }

        private func cameraYawRadians(_ t: simd_float4x4) -> Float {
            let zAxis = SIMD3<Float>(t.columns.2.x, t.columns.2.y, t.columns.2.z)
            return atan2f(-zAxis.x, -zAxis.z)
        }

        // Finish tapped — award 40 XP, log history, mark as reading, and exit (pop to Home)
        @objc func finishTapped() {
            let award = 40 // XP per book found
            _ = parent.progress.awardExp(award)
            parent.progress.addHistory(bookId: parent.book.id, title: parent.book.title, action: .found, exp: award)

            // Start reading this book now
            parent.progress.startReading(bookId: parent.book.id)

            let after = parent.progress.level
            let toNext = parent.progress.expToNextLevel
            let parts = ["Found: \(parent.book.title)", "+\(award) XP", "Level \(after)", "\(toNext) XP to next"]
            toastLabel?.text = parts.joined(separator: " • ")
            showToastThenExit(popToRoot: true)
        }

        // Missing Book tapped — confirm, award 20 XP, log history, and go Home (pop to root)
        @objc func missingTapped() {
            guard let vc = arView?.window?.rootViewController else { return }
            let alert = UIAlertController(title: "Confirm", message: "Are you sure the book is lost?", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
            alert.addAction(UIAlertAction(title: "Yes", style: .destructive, handler: { [weak self] _ in
                guard let self else { return }
                let award = 20
                _ = self.parent.progress.awardExp(award)
                self.parent.progress.addHistory(bookId: self.parent.book.id, title: self.parent.book.title, action: .missing, exp: award)

                let after = self.parent.progress.level
                let toNext = self.parent.progress.expToNextLevel
                let parts = ["Marked missing: \(self.parent.book.title)", "+\(award) XP", "Level \(after)", "\(toNext) XP to next"]
                self.toastLabel?.text = parts.joined(separator: " • ")
                self.showToastThenExit(popToRoot: true)
            }))
            vc.present(alert, animated: true, completion: nil)
        }
    }
}

// Small helpers
private extension SIMD4 where Scalar == Float {
    var xyz: SIMD3<Float> { SIMD3<Float>(x, y, z) }
}
