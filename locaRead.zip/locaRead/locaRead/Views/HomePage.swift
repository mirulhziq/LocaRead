//
//  HomePage.swift
//  NoteNess
//
//  Created by STDC_35 on 18/09/2025.
//

import SwiftUI
import UIKit

// MARK: - Home Page
struct HomePage: View {
    @EnvironmentObject var store: LibraryStore
    @EnvironmentObject var router: Router

    @State private var searchText: String = ""
    @State private var toastMessage: String? = nil

    var body: some View {
        ZStack(alignment: .top) {
            VStack(alignment: .leading, spacing: 15) {
                header

                searchBar

                ScrollView {
                    VStack(alignment: .leading, spacing: 30) {
                        ForEach(orderedDisplayCategories, id: \.self) { displayCategory in
                            let books = filteredBooks(inDisplayCategory: displayCategory)
                            if !books.isEmpty {
                                HomeCategorySectionView(
                                    title: displayCategory,
                                    books: books,
                                    onSelect: { book in
                                        router.path.append(.bookDetail(book: book))
                                    },
                                    onFavorite: { book in
                                        // Determine current state before toggling
                                        let wasFavorite = store.isFavorite(book)
                                        store.toggleFavorite(book)

                                        // Haptic + toast with appropriate message
                                        let generator = UINotificationFeedbackGenerator()
                                        generator.notificationOccurred(.success)
                                        withAnimation(.spring(response: 0.4, dampingFraction: 0.9)) {
                                            toastMessage = wasFavorite ? "Removed from Favourite" : "Add to Favourite"
                                        }
                                        DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) {
                                            withAnimation(.easeInOut(duration: 0.25)) {
                                                toastMessage = nil
                                            }
                                        }
                                    }
                                )
                                Divider()
                            }
                        }
                    }
                    .padding()
                }
            }

            // Simple top toast
            if let msg = toastMessage {
                ToastView(message: msg)
                    .transition(.move(edge: .top).combined(with: .opacity))
                    .padding(.top, 8)
            }
        }
        .onAppear {
            // If needed, preload sample/JSON when bundle JSON is missing.
            if store.data == nil {
                store.loadFromBundle()
            }
        }
    }

    // MARK: - Header
    private var header: some View {
        HStack(spacing: 12) {
            // Use your app logo asset ("Image"). If you add a dedicated logo asset, replace the name here.
            Image("Image")
                .resizable()
                .scaledToFit()
                .frame(width: 36, height: 36)
                .padding(8)
                .background(.thinMaterial)
                .clipShape(RoundedRectangle(cornerRadius: 10))
                .shadow(radius: 4)

            Text("Home")
                .font(.largeTitle)
                .fontWeight(.bold)
                .foregroundColor(Color.blue)

            Spacer()
        }
        .padding(.horizontal)
    }

    // MARK: - Data helpers
    private var allBooks: [Book] {
        store.data?.books ?? []
    }

    // Use book.category as the authority (“book data”).
    // Fall back to shelf.category only if a book has an empty category.
    private func canonicalCategory(for book: Book) -> String {
        let raw = book.category.trimmingCharacters(in: .whitespacesAndNewlines)
        if !raw.isEmpty { return raw }
        if let shelfCat = store.shelf(for: book)?.category.trimmingCharacters(in: .whitespacesAndNewlines),
           !shelfCat.isEmpty {
            return shelfCat
        }
        return "Uncategorized"
    }

    private func normalizedKey(_ category: String) -> String {
        category.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
    }

    // Group books by normalized category, and choose a display label that matches book data.
    private var groupedByDisplayCategory: [String: [Book]] {
        // Step 1: Build groups by normalized key
        var groups: [String: [Book]] = [:]
        var keyToDisplay: [String: String] = [:]

        for book in allBooks {
            let cat = canonicalCategory(for: book)
            let key = normalizedKey(cat)
            groups[key, default: []].append(book)

            // Prefer the exact category as written in book data for display
            if keyToDisplay[key] == nil {
                keyToDisplay[key] = cat
            }
        }

        // Step 2: Transform to [displayName: books]
        var byDisplay: [String: [Book]] = [:]
        for (key, books) in groups {
            let display = keyToDisplay[key] ?? key.capitalized
            byDisplay[display] = books
        }
        return byDisplay
    }

    private var orderedDisplayCategories: [String] {
        // Preferred order first, then any others alphabetically
        let preferred = ["Fiction", "History", "Science & Technology"]

        let existingDisplays = Array(groupedByDisplayCategory.keys)
        let existingSet = Set(existingDisplays)

        let preferredExisting = preferred.filter { existingSet.contains($0) }
        let remaining = existingDisplays.filter { !preferredExisting.contains($0) }.sorted()
        return preferredExisting + remaining
    }

    private func filteredBooks(inDisplayCategory display: String) -> [Book] {
        let inCategory = groupedByDisplayCategory[display] ?? []
        guard !searchText.isEmpty else { return inCategory }
        return inCategory.filter {
            $0.title.localizedCaseInsensitiveContains(searchText) ||
            $0.callNumber.localizedCaseInsensitiveContains(searchText) ||
            canonicalCategory(for: $0).localizedCaseInsensitiveContains(searchText)
        }
    }
}

// MARK: - Category Section (Horizontal scroll with favourite button)
struct HomeCategorySectionView: View {
    @EnvironmentObject var router: Router
    @EnvironmentObject var store: LibraryStore

    let title: String
    let books: [Book]
    var onSelect: (Book) -> Void
    var onFavorite: (Book) -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text(title)
                .font(.title2)
                .fontWeight(.bold)
                .padding(.horizontal, 5)

            ScrollView(.horizontal, showsIndicators: false) {
                HStack(alignment: .top, spacing: 15) {
                    ForEach(books) { book in
                        BookCardWithFavorite(
                            book: book,
                            onDetails: { onSelect(book) },
                            onFavorite: {
                                onFavorite(book)
                            }
                        )
                        .frame(width: 120, height: 220)
                        .contextMenu {
                            Button {
                                onSelect(book)
                            } label: {
                                Label("Open Details", systemImage: "info.circle")
                            }
                            Button {
                                onFavorite(book)
                            } label: {
                                Label(store.isFavorite(book) ? "Remove Favourite" : "Add Favourite",
                                      systemImage: store.isFavorite(book) ? "heart.slash" : "heart")
                            }
                        }
                    }
                }
                .padding(.horizontal, 5)
            }
        }
    }
}

// MARK: - Book Card (strict asset name = Book.id)
struct BookCard: View {
    let book: Book
    private let coverSize = CGSize(width: 120, height: 180)
    private let titleHeight: CGFloat = 34 // Enough for up to 2 lines of .caption

    var body: some View {
        VStack(spacing: 6) {
            ZStack {
                RoundedRectangle(cornerRadius: 12)
                    .fill(Color.gray.opacity(0.15))
                    .frame(width: coverSize.width, height: coverSize.height)
                    .shadow(radius: 4)

                if let uiImage = coverUIImage(for: book) {
                    Image(uiImage: uiImage)
                        .resizable()
                        .scaledToFill()
                        .frame(width: coverSize.width, height: coverSize.height)
                        .clipped()
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                } else {
                    Image(systemName: "text.book.closed.fill")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 60, height: 60)
                        .foregroundColor(.accentColor)
                }
            }

            Text(book.title)
                .font(.caption)
                .multilineTextAlignment(.center)
                .lineLimit(2)
                .frame(width: coverSize.width, height: titleHeight, alignment: .top)
                .foregroundColor(.primary)
        }
        .accessibilityElement(children: .combine)
        .accessibilityLabel("\(book.title), \(book.category)")
    }

    private func coverUIImage(for book: Book) -> UIImage? {
        UIImage(named: book.id)
    }
}

// MARK: - Book Card with Favourite overlay and tap for details
struct BookCardWithFavorite: View {
    @EnvironmentObject var store: LibraryStore

    let book: Book
    let onDetails: () -> Void
    let onFavorite: () -> Void

    var body: some View {
        ZStack(alignment: .topTrailing) {
            BookCard(book: book)
                .contentShape(RoundedRectangle(cornerRadius: 12))
                .onTapGesture {
                    onDetails()
                }

            Button(action: {
                onFavorite()
            }) {
                Image(systemName: store.isFavorite(book) ? "heart.fill" : "heart")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(store.isFavorite(book) ? .red : .white)
                    .padding(8)
                    .background(
                        Circle()
                            .fill(store.isFavorite(book) ? Color.white : Color.indigo)
                    )
                    .shadow(radius: 3)
            }
            .buttonStyle(.plain)
            .padding(6)
            .accessibilityLabel((store.isFavorite(book) ? "Remove from" : "Add to") + " favourites for \(book.title)")
        }
    }
}

// MARK: - Search Bar
extension HomePage {
    private var searchBar: some View {
        HStack {
            Image(systemName: "magnifyingglass")
                .opacity(0.6)
            TextField("Search books by title, call number, or category...", text: $searchText)
                .textFieldStyle(PlainTextFieldStyle())
        }
        .padding()
        .background(Color.gray.opacity(0.2))
        .cornerRadius(20)
        .padding(.horizontal)
        .padding(.top, 12) // increased space between "Home" title and search bar
    }
}

// MARK: - Toast View
private struct ToastView: View {
    let message: String

    var body: some View {
        Text(message)
            .font(.subheadline).bold()
            .padding(.horizontal, 16)
            .padding(.vertical, 10)
            .background(.ultraThinMaterial)
            .clipShape(Capsule())
            .shadow(radius: 6)
    }
}

// MARK: - Preview
#Preview {
    let store = LibraryStore()
    store.useSampleData()

    return HomePage()
        .environmentObject(store)
        .environmentObject(Router())
}
