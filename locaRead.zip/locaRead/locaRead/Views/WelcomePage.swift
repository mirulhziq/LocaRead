//
//  WelcomePage.swift
//  NoteNess
//
//  Created by STDC_35 on 18/09/2025.
//

import SwiftUI

struct WelcomePage: View {
    // Animate the app icon and title
    @State private var scale: CGFloat = 0.6
    @State private var opacity: Double = 0.0
    @State private var blur: CGFloat = 10
    @State private var showTitle: Bool = false

    // Call when the splash finishes so the parent can dismiss it
    var onFinish: () -> Void = {}

    var body: some View {
        ZStack {
            // Background
            Color(.systemBackground)
                .ignoresSafeArea()

            VStack(spacing: 16) {
                // IMPORTANT:
                // iOS does not allow loading the AppIcon asset directly by name.
                // Add an image asset for your logo (e.g., "AppLogo" or reuse your "Image" asset).
                // Replace "Image" below with your logo asset name if needed.
                Image("Image")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 120, height: 120)
                    .shadow(color: .black.opacity(0.25), radius: 12, x: 0, y: 6)
                    .scaleEffect(scale)
                    .opacity(opacity)
                    .blur(radius: blur)
                    .accessibilityLabel("App Icon")

                Text("LocaRead")
                    .font(.system(.largeTitle, design: .rounded))
                    .fontWeight(.heavy)
                    .foregroundColor(Color(hue: 0.536, saturation: 0.968, brightness: 0.991, opacity: 0.982))
                    .opacity(showTitle ? 1 : 0)
                    .offset(y: showTitle ? 0 : 8)
                    .animation(.easeOut(duration: 0.5), value: showTitle)
            }
        }
        .onAppear {
            runAnimation()
        }
    }

    private func runAnimation() {
        Task {
            // Pop-in the logo
            withAnimation(.spring(response: 0.6, dampingFraction: 0.8, blendDuration: 0.2)) {
                scale = 1.0
                opacity = 1.0
                blur = 0
            }

            // After the logo settles, reveal the title
            try? await Task.sleep(nanoseconds: 700_000_000)
            withAnimation(.easeInOut(duration: 0.5)) {
                showTitle = true
            }

            // Brief hold
            try? await Task.sleep(nanoseconds: 700_000_000)

            // Zoom/fade out to transition into the app
            withAnimation(.easeInOut(duration: 0.5)) {
                scale = 1.12
                opacity = 0.0
            }

            // Give the fade a moment to complete
            try? await Task.sleep(nanoseconds: 520_000_000)
            onFinish()
        }
    }
}

#Preview {
    // Standalone preview
    WelcomePage()
}
