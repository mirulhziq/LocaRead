import SwiftUI

enum Route: Hashable {
    case home
    case searchResults(query: String)
    case bookDetail(book: Book)
    case map(book: Book)
    case ar(book: Book)
}

final class Router: ObservableObject {
    @Published var path: [Route] = []
    func popToRoot() { path = [] }
}
