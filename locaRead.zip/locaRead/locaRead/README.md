# locaRead - Library Navigator App

This is an iOS SwiftUI app that allows users to browse and search for books, view their details, locate them on a floor map, and get AR guidance to the target shelf.

## How to Run

1.  **Simulator:** For testing UI and map features, you can run the app on any iOS Simulator.
2.  **Real Device:** For Augmented Reality (AR) features, you *must* run the app on a physical iOS device that supports ARKit (e.g., iPhone 6s or later, iPad Pro, or 2017 iPad or later).

### Steps to Run:

1.  Open the `locaRead.xcodeproj` file in Xcode.
2.  **Crucially, replace the placeholder `locaRead/Resources/floor_map.png` with your actual floor map image.**
    For optimal display, ensure its dimensions match those specified in `library.json` (1000x600 pixels).

3.  Select your target device:
3.  Build and run the project.

## Project Structure

```
locaRead/
  locaReadApp.swift
  Models/
    LibraryModels.swift
  Data/
    LibraryStore.swift
  Router/
    Router.swift
  Views/
    RootView.swift
    HomeView.swift
    SearchBar.swift
    BookRow.swift
    SearchResultsView.swift
    BookDetailView.swift
    MapView.swift
    TinyLoader.swift
    ARGuideView.swift
    ARViewPlaceholder.swift
  Resources/
    library.json
    floor_map.png
    README.md
```

## AR Guidance Details

### Floor Coordinates to AR Meters Mapping

The `library.json` defines `x` and `y` coordinates for shelves within a `floor_map.png` image (e.g., `1000x600` units). In the AR view, these coordinates are scaled to real-world meters using the following conversion factors:

-   `scaleX = 0.005` meters per floor-unit (e.g., 1000 map units correspond to 5.0 meters in AR).
-   `scaleY = 0.005` meters per floor-unit (e.g., 600 map units correspond to 3.0 meters in AR).

Shelf positions in AR are calculated as:

`pos = SIMD3<Float>( Float(x_map * scaleX), 0, Float(-y_map * scaleY) )`

(Note: `negative Z` is used so that "down" the 2D map (increasing `y_map`) corresponds to moving forward/away in the AR view (`decreasing Z` in RealityKit's coordinate system).

### Arrow Yaw Calculation

The directional arrow in the AR view updates its orientation (yaw only) to point towards the target shelf. The yaw angle is calculated using `atan2`:

`let yaw = atan2(vectorToTarget.x, vectorToTarget.z)`

Where `vectorToTarget` is the vector from the arrow's world position to the target shelf's world position. The `atan2` function correctly handles all quadrants, giving an angle relative to the positive Z-axis (which represents forward in RealityKit).

### Avoiding RealityKit API Errors (Cone Generation)

To ensure compatibility across different iOS 17+ toolchains and avoid potential signature mismatches with `MeshResource.generateCone(height:radius:)`, the directional arrow is built entirely from `MeshResource.generateBox` primitives:

-   **Shaft:** `0.02m × 0.02m × 0.14m` box
-   **Head:** `0.04m × 0.02m × 0.06m` box, positioned at the front of the shaft.
