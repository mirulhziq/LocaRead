import Foundation
import Combine

class LibraryStore: ObservableObject {
    @Published var data: LibraryData?
    @Published var isLoading = true
    @Published var searchQuery = ""
    @Published var searchResults: [Book] = []
    @Published var selectedBook: Book?
    private(set) var shelvesById: [String: Shelf] = [:]

    // Favourites (persisted)
    @Published private(set) var favoriteIDs: Set<String> = []
    private let favoritesKey = "favorites.bookIDs"

    init() {
        loadFavorites()
    }

    // Use the in-app sample data (BookData.sample)
    func useSampleData() {
        let sample = BookData.sample
        applyData(sample)
    }

    func loadFromBundle() {
        isLoading = true
        DispatchQueue.global(qos: .background).async {
            guard let url = Bundle.main.url(forResource: "library", withExtension: "json") else {
                print("LibraryStore: library.json not found. Falling back to BookData.sample.")
                DispatchQueue.main.async { self.useSampleData() }
                return
            }

            do {
                let data = try Data(contentsOf: url)
                let decoder = JSONDecoder()
                let libraryData = try decoder.decode(LibraryData.self, from: data)
                DispatchQueue.main.async {
                    self.applyData(libraryData)
                }
            } catch {
                print("LibraryStore: Failed to load/decode library.json (\(error)). Falling back to BookData.sample.")
                DispatchQueue.main.async { self.useSampleData() }
            }
        }
    }

    func searchBooks(_ query: String) {
        guard let libraryData = data else { return }
        if query.isEmpty {
            searchResults = libraryData.books
            return
        }

        let lowercasedQuery = query.lowercased()
        var exactMatches: [Book] = []
        var partialMatches: [Book] = []
        var categoryMatches: [Book] = []

        // Search by category matching shelf category
        let matchingShelfCategories = libraryData.shelves.filter { $0.category.lowercased() == lowercasedQuery }
        if !matchingShelfCategories.isEmpty {
            let matchingShelfIds = Set(matchingShelfCategories.map { $0.id })
            categoryMatches = libraryData.books.filter { matchingShelfIds.contains($0.shelfId) }
        }

        for book in libraryData.books {
            if book.id.lowercased() == lowercasedQuery ||
               book.title.lowercased() == lowercasedQuery ||
               book.category.lowercased() == lowercasedQuery ||
               book.callNumber.lowercased() == lowercasedQuery {
                exactMatches.append(book)
            } else if book.id.lowercased().contains(lowercasedQuery) ||
                      book.title.lowercased().contains(lowercasedQuery) ||
                      book.category.lowercased().contains(lowercasedQuery) ||
                      book.callNumber.lowercased().contains(lowercasedQuery) {
                partialMatches.append(book)
            }
        }
        
        // Combine results: exact, then category, then partial, removing duplicates
        var combinedResults = [Book]()
        let allMatches = exactMatches + categoryMatches + partialMatches
        var seenIds = Set<String>()
        for book in allMatches {
            if !seenIds.contains(book.id) {
                combinedResults.append(book)
                seenIds.insert(book.id)
            }
        }
        searchResults = combinedResults
    }

    func shelf(for book: Book) -> Shelf? {
        shelvesById[book.shelfId]
    }

    func reset() {
        selectedBook = nil
        searchQuery = ""
        searchResults = data?.books ?? []
    }

    // MARK: - Favourites
    func isFavorite(_ book: Book) -> Bool {
        favoriteIDs.contains(book.id)
    }

    func toggleFavorite(_ book: Book) {
        if favoriteIDs.contains(book.id) {
            favoriteIDs.remove(book.id)
        } else {
            favoriteIDs.insert(book.id)
        }
        saveFavorites()
    }

    private func loadFavorites() {
        if let arr = UserDefaults.standard.array(forKey: favoritesKey) as? [String] {
            favoriteIDs = Set(arr)
        } else {
            favoriteIDs = []
        }
    }

    private func saveFavorites() {
        UserDefaults.standard.set(Array(favoriteIDs), forKey: favoritesKey)
    }

    // MARK: - Helpers
    private func applyData(_ libraryData: LibraryData) {
        self.data = libraryData
        self.shelvesById = libraryData.shelves.reduce(into: [:]) { $0[$1.id] = $1 }
        self.searchResults = libraryData.books
        self.isLoading = false
    }
}
