import SwiftUI

@main
struct locaReadApp: App {
    @StateObject var store = LibraryStore()
    @StateObject var router = Router()
    @StateObject var progress = UserProgressStore()   // NEW: progress store

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(store)
                .environmentObject(router)
                .environmentObject(progress)          // NEW: inject into environment
                .onAppear {
                    // Force the app to use the in-code data from BookData.swift
                    store.useSampleData()
                    // If you ever want to go back to JSON loading, replace with:
                    // store.loadFromBundle()
                }
        }
    }
}
